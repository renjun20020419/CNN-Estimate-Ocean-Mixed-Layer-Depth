# Mixed-layer depth CNN and layerwise source allocation

This repository candidate contains a portable reference implementation of the
five-input mixed-layer depth (MLD) CNN, spatial partitioning, layerwise source
allocation, and allocation-based analyses. The displayed study model uses four
Conv–BatchNorm–GELU blocks, 250 feature maps per block, kernel width 15, and 500
input levels. Its training seed is `20260617`, with spatial split seed `20261016`.

This package contains source code only. It does not distribute the study's
observations, labels, per-profile results, weights, manuscript, or review
materials. The example below generates its own synthetic inputs.

## Key files

| File | Purpose |
| --- | --- |
| `mldcnn/model.py` | Temperature-derived input channels, standardization, and CNN architecture |
| `mldcnn/split.py` | Train/validation/test split with whole 10° spatial cells kept together |
| `mldcnn/train.py` | Training-set normalization, model fitting, validation-based checkpoint selection, and prediction metrics |
| `mldcnn/attribute.py` | Signed source propagation relative to a standardized-zero reference and layerwise five-component allocation fractions |
| `mldcnn/analyze.py` | Layerwise clustering, label-matched transitions, ARI/NMI, and channel-perturbation agreement |

## Installation and example

Use Python 3.10 or later. From the repository root, install the package in a
virtual environment. The example uses CPU; for a larger run, select a compatible
PyTorch build and pass `--device cuda` to the training and analysis commands.

```sh
python -m pip install .
python -m mldcnn.demo --out demo_run/profiles.npz
python -m mldcnn.split --data demo_run/profiles.npz --out demo_run/split.npz
python -m mldcnn.train --data demo_run/profiles.npz --split demo_run/split.npz --out demo_run/model --device cpu --epochs 2 --batch-size 32 --channels 8 8 8 8 --kernel-sizes 3 3 3 3
python -m mldcnn.attribute --data demo_run/profiles.npz --checkpoint demo_run/model/checkpoint.pt --out demo_run/allocations.npz
python -m mldcnn.analyze --data demo_run/profiles.npz --split demo_run/split.npz --checkpoint demo_run/model/checkpoint.pt --allocations demo_run/allocations.npz --out demo_run/analysis
python -m unittest discover -s tests -v
```

The toy model is intentionally small. Its scores are not evidence about the
study. Use a fresh output directory for each run. Pass `--help` to any module
for options.

## Input format

Supply an `.npz` file with these arrays in the **same profile order**:

| Key | Shape | Meaning |
| --- | --- | --- |
| `temperature` | `(N, L)` | Finite, unstandardized temperatures on aligned profile levels, shallow to deep |
| `mld` | `(N,)` | Finite target values on a documented, common scale |
| `lat` | `(N,)` | Latitude in degrees, from −90 to 90 |
| `lon` | `(N,)` | Longitude in degrees, wrapped to [−180, 180) for grid assignment |
| `profile_id` | `(N,)`, optional | Plain Unicode identifiers; outputs index rows by zero-based position |

No interpolation, raw-file parsing, or conversion of MLD indices to physical
depth is performed. Prepare consistent inputs and confirm the target scale
before training. The two temperature gradients and cumulative-variance
gradient use sample-level spacing as in the study implementation. The
cumulative variance includes the current level. Feature and target means and
standard deviations are fitted on training rows only; temperature profiles
are not standardized individually. To use the displayed model's length, pass
`--profile-len 500` and supply at least 500 levels.

The split file stores `train_idx`, `val_idx`, `test_idx`, `grid_id`, and the seed.
The split uses only coordinates and cell counts. Fractions target 80/10/10 but
need not match them exactly. Grid separation does not impose a minimum
distance between profiles in adjacent cells.

## Outputs and interpretation

- Training writes `checkpoint.pt`, `training_history.csv`, `metrics.json`, and
  `predictions.npz`. The checkpoint contains the model configuration and
  training-fitted normalization parameters. Predictions retain the input MLD
  target scale. The best epoch is selected by validation MAE.
- Attribution writes `allocations.npz` with `P` of shape `(N, layers, 5)`, the
  source row indices, channel order, file hashes, and maximum reconstruction
  error by layer. It propagates signed differences through Conv–BN and GELU
  secant rescaling. The reported fractions normalize absolute source magnitudes
  across maps and profile levels. They are reference-dependent summaries of
  internal activations, not causal fractions of the final prediction.
- Analysis writes `analysis.json` and `analysis_arrays.npz`. By default, K-means
  is fitted separately per layer with `K=5`, seed 42, and 120 initializations.
  The all-profile fit is descriptive. `--cluster-fit train` fits centers on
  training profiles and evaluates the fixed centers on test profiles. Latitude
  only orders the display labels after fitting. ARI and NMI do not depend on
  label names; the matched switch rate uses maximum-overlap one-to-one label
  matching. Layerwise stabilization is not assumed.
- Perturbation defaults to the full test split, with no error-based filtering.
  It sets one standardized input channel to zero, leaves the other channels
  fixed, and measures the absolute final prediction change. These are model
  interventions, not physically self-consistent changes to the original
  temperature profile. Top-two and bottom-two agreement use average ranks by
  default. `--rank-ties historical` selects the original supplementary table's
  tie rule. Paired rank-biserial correlations compare the effects of the
  highest- and lowest-allocation channels within profiles.

## Reproduction scope

This is a release-oriented extraction of the key computational methods, not
an archive of all experiments. It does not reconstruct the manuscript's
prediction-error-filtered figures or reproduce reported values without the
original prepared inputs and matching trained model. It omits manuscript
plot styling, SHAP, and experiment-specific postprocessing. Exact training
results can vary across hardware and software versions.

## Verification

The CPU example was run end to end on 240 generated profiles. The tests check
feature definitions, non-overlapping spatial cells, deterministic splitting,
and signed-source reconstruction. Local comparisons against the archived
implementation also checked split assignments, model predictions, and sampled
allocation fractions. No archived inputs or weights are included. The checked
environment used Python 3.12, NumPy 2.3.5, PyTorch 2.11, SciPy 1.17, and
scikit-learn 1.8.

## Before public release

This draft does not grant a license. The rights holder should choose a license
and add authorship, citation, and any data-access information they are entitled
to share before publishing. Do not include local data or generated run outputs
when uploading the source.
