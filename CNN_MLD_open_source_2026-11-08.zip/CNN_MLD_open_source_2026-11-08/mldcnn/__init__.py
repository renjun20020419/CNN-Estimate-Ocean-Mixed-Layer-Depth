"""Reference implementation of profile CNN source-allocation analysis."""

__version__ = "0.1.0"
