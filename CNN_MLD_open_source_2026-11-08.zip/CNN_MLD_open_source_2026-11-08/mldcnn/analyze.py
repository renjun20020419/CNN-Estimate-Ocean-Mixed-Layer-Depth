"""Cluster layer allocations and compare their ranks with channel interventions.

This is a data-in/data-out analysis, not a reproduction of the manuscript's
error-filtered cohort or plotting workflow. No error-based filtering is applied.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from scipy.optimize import linear_sum_assignment
from scipy.stats import rankdata
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from threadpoolctl import threadpool_limits

from .model import CHANNEL_NAMES as CHANNELS
from .model import build_5_channels, load_checkpoint, standardize_channels


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_split(path, n):
    parts = {}
    with np.load(path, allow_pickle=False) as archive:
        for part in ("train", "val", "test"):
            key = part + "_idx"
            ids = archive[key]
            if (ids.ndim != 1 or not np.issubdtype(ids.dtype, np.integer)
                    or not len(ids) or np.any(ids < 0) or np.any(ids >= n)):
                raise ValueError(f"{key} must be a nonempty vector of valid row indices")
            parts[part] = ids.astype(np.int64, copy=False)
    combined = np.concatenate(list(parts.values()))
    if len(np.unique(combined)) != len(combined):
        raise ValueError("Split indices must be unique and disjoint")
    return parts


def read_allocations(path, n, data_sha256, checkpoint_sha256):
    checked = []
    with np.load(path, allow_pickle=False) as archive:
        p = np.asarray(archive["P"], dtype=np.float64)
        ids = archive["sample"]
        for key, expected in (("data_sha256", data_sha256),
                              ("checkpoint_sha256", checkpoint_sha256),
                              ("model_sha256", checkpoint_sha256)):
            if key in archive:
                if str(archive[key].item()) != expected:
                    raise ValueError(f"Allocation archive {key} does not match the supplied file")
                checked.append(key)
        if "channels" in archive and archive["channels"].tolist() != list(CHANNELS):
            raise ValueError("Allocation archive has an unexpected channel order")
    if p.ndim != 3 or p.shape[0] != n or p.shape[1] < 1 or p.shape[2] != len(CHANNELS):
        raise ValueError("P must have shape (N, number of layers, 5)")
    if ids.shape != (n,) or not np.issubdtype(ids.dtype, np.integer):
        raise ValueError("sample must be a vector of N integer source-row indices")
    order = np.argsort(ids)
    if not np.array_equal(ids[order], np.arange(n)):
        raise ValueError("Allocation archive must contain each input row exactly once")
    if not np.isfinite(p).all() or np.any(p < 0) or not np.allclose(p.sum(axis=2), 1.0, atol=1e-6):
        raise ValueError("P must contain finite, nonnegative allocation fractions summing to one")
    return p[order], checked


def cluster_allocations(p, lat, fit_idx, eval_idx, k=5, seed=42, n_init=120):
    """Fit each layer separately in allocation space; latitude only relabels."""
    if not 2 <= k <= len(fit_idx):
        raise ValueError("k must be between 2 and the number of fitting profiles")
    centers, eval_labels, layer_summaries = [], [], []
    for layer in range(p.shape[1]):
        model = KMeans(n_clusters=k, random_state=seed, n_init=n_init)
        fit_p = p[fit_idx, layer]
        if len(np.unique(fit_p, axis=0)) < k:
            raise ValueError(f"Layer {layer + 1} has fewer than k distinct fitting allocations")
        with threadpool_limits(limits=1):
            labels = model.fit_predict(fit_p)
        if len(np.unique(labels)) != k:
            raise ValueError(f"Layer {layer + 1} K-means did not yield k occupied fitting groups")
        mean_abs_lat = np.array([np.abs(lat[fit_idx][labels == c]).mean() for c in range(k)])
        order = np.argsort(mean_abs_lat, kind="stable")
        remap = np.empty(k, dtype=np.int64)
        remap[order] = np.arange(k)
        # Use fitting-set latitude for numbering even when evaluating held-out rows.
        if np.array_equal(eval_idx, fit_idx):
            pred = remap[labels]
        else:
            with threadpool_limits(limits=1):
                pred = remap[model.predict(p[eval_idx, layer])]
        centers.append(model.cluster_centers_[order])
        eval_labels.append(pred)
        layer_summaries.append({
            "layer": layer + 1,
            "fit_cluster_sizes": np.bincount(remap[labels], minlength=k).tolist(),
            "evaluation_cluster_sizes": np.bincount(pred, minlength=k).tolist(),
            "fit_mean_absolute_latitude": mean_abs_lat[order].tolist(),
        })
    return np.stack(centers), np.column_stack(eval_labels), layer_summaries


def adjacent_transitions(labels, p, k):
    """Summarize fixed memberships; one-to-one matching changes IDs only."""
    reports = []
    for layer in range(labels.shape[1] - 1):
        a, b = labels[:, layer], labels[:, layer + 1]
        counts = np.zeros((k, k), dtype=np.int64)
        np.add.at(counts, (a, b), 1)
        row, col = linear_sum_assignment(-counts)
        mapping = np.empty(k, dtype=np.int64)
        mapping[col] = row
        reports.append({
            "from_layer": layer + 1,
            "to_layer": layer + 2,
            "raw_switch_percent": float(100 * np.mean(a != b)),
            "matched_switch_percent": float(100 * np.mean(a != mapping[b])),
            "ari": float(adjusted_rand_score(a, b)),
            "nmi": float(normalized_mutual_info_score(a, b, average_method="arithmetic")),
            "mean_allocation_l1": float(np.abs(p[:, layer] - p[:, layer + 1]).sum(axis=1).mean()),
            "contingency_earlier_by_later": counts.tolist(),
            "later_to_earlier_label": mapping.tolist(),
        })
    return reports


@torch.inference_mode()
def channel_interventions(model, normalized_x, device, target_mean, target_std, batch_size):
    """Zero one standardized channel at a time; do not recompute derived features."""
    baseline, ablated = [], []
    model.eval()
    for i in range(0, len(normalized_x), batch_size):
        x = torch.as_tensor(normalized_x[i:i + batch_size], dtype=torch.float32, device=device)
        baseline.append(model(x).reshape(-1).cpu().numpy())
        result = []
        for channel in range(len(CHANNELS)):
            changed = x.clone()
            changed[:, channel, :] = 0
            result.append(model(changed).reshape(-1).cpu().numpy())
        ablated.append(np.column_stack(result))
    baseline = np.concatenate(baseline).astype(np.float64) * target_std + target_mean
    ablated = np.concatenate(ablated).astype(np.float64) * target_std + target_mean
    if not np.isfinite(baseline).all() or not np.isfinite(ablated).all():
        raise ValueError("Model returned a nonfinite baseline or perturbed prediction")
    return baseline, ablated


def perturbation_agreement(p, effects, tie_rule="average"):
    """Check extreme allocations against five final-output perturbation ranks."""
    if tie_rule == "historical":
        descending = rankdata(-effects, axis=1, method="min")
        largest, smallest = descending <= 2, descending >= 4
    elif tie_rule == "average":
        largest = rankdata(-effects, axis=1, method="average") <= 2
        smallest = rankdata(effects, axis=1, method="average") <= 2
    else:
        raise ValueError(f"Unsupported tie rule: {tie_rule}")
    rows = np.arange(len(effects))
    result = []
    for layer in range(p.shape[1]):
        v = p[:, layer]
        # np.argmax/argmin choose the first channel when allocations are tied.
        high, low = v.argmax(axis=1), v.argmin(axis=1)
        hi, lo = effects[rows, high], effects[rows, low]
        d = hi - lo
        nonzero = d[d != 0]
        ranks = rankdata(np.abs(nonzero), method="average")
        r = float(np.dot(np.sign(nonzero), ranks) / ranks.sum()) if len(ranks) else None
        high_counts = np.bincount(high, minlength=len(CHANNELS))
        low_counts = np.bincount(low, minlength=len(CHANNELS))
        result.append({
            "layer": layer + 1,
            "n": len(effects),
            "highest_allocation_channel_counts": high_counts.tolist(),
            "lowest_allocation_channel_counts": low_counts.tolist(),
            "highest_allocation_channel_percent": (100 * high_counts / len(effects)).tolist(),
            "lowest_allocation_channel_percent": (100 * low_counts / len(effects)).tolist(),
            "highest_allocation_tie_n": int(np.sum(np.sum(v == v.max(axis=1, keepdims=True), axis=1) > 1)),
            "lowest_allocation_tie_n": int(np.sum(np.sum(v == v.min(axis=1, keepdims=True), axis=1) > 1)),
            "highest_in_top_two_n": int(largest[rows, high].sum()),
            "highest_in_top_two_percent": float(100 * largest[rows, high].mean()),
            "lowest_in_bottom_two_n": int(smallest[rows, low].sum()),
            "lowest_in_bottom_two_percent": float(100 * smallest[rows, low].mean()),
            "rank_biserial_r": r,
            "paired_zero_difference_n": int(np.sum(d == 0)),
            "highest_mean_effect": float(hi.mean()),
            "lowest_mean_effect": float(lo.mean()),
        })
    return result


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", type=Path, required=True, help="NPZ containing temperature, mld, lat and lon")
    p.add_argument("--split", type=Path, required=True, help="NPZ containing train_idx, val_idx, test_idx")
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--allocations", type=Path, required=True, help="NPZ containing P and sample")
    p.add_argument("--out", type=Path, required=True, help="Output directory")
    p.add_argument("--device", default="cpu", help="PyTorch device, e.g. cpu or cuda")
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--threads", type=int, default=2, help="Number of PyTorch CPU intra-op threads")
    p.add_argument("--cluster-fit", choices=("all", "train"), default="all",
                   help="all: descriptive fit/evaluation; train: fit on train, evaluate test")
    p.add_argument("--perturb-subset", choices=("test", "val", "val-test"), default="test")
    p.add_argument("--k", type=int, default=5)
    p.add_argument("--seed", type=int, default=42, help="K-means initialization seed")
    p.add_argument("--n-init", type=int, default=120)
    p.add_argument("--rank-ties", choices=("average", "historical"), default="average")
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    if min(args.batch_size, args.n_init, args.threads) < 1:
        raise ValueError("batch-size, n-init and threads must be positive")
    torch.set_num_threads(args.threads)
    if any((args.out / name).exists() for name in ("analysis.json", "analysis_arrays.npz")):
        raise FileExistsError("Analysis outputs already exist; choose a different --out directory")
    with np.load(args.data, allow_pickle=False) as data:
        temp = np.asarray(data["temperature"], dtype=np.float32)
        lat = np.asarray(data["lat"], dtype=np.float64)
        mld = np.asarray(data["mld"], dtype=np.float64)
    if (temp.ndim != 2 or not len(temp) or lat.shape != (len(temp),)
            or mld.shape != (len(temp),) or not np.isfinite(temp).all()
            or not np.isfinite(lat).all() or not np.isfinite(mld).all()
            or np.any(np.abs(lat) > 90)):
        raise ValueError("Expected finite temperature (N,L), latitude (N,) and mld (N,)")
    parts = read_split(args.split, len(temp))
    hashes = {key: sha256_file(getattr(args, key))
              for key in ("data", "split", "checkpoint", "allocations")}
    p, checked = read_allocations(args.allocations, len(temp), hashes["data"], hashes["checkpoint"])
    device = torch.device(args.device)
    model, checkpoint = load_checkpoint(args.checkpoint, device)
    if tuple(checkpoint.get("channel_names", CHANNELS)) != tuple(CHANNELS):
        raise ValueError("Checkpoint has an unexpected channel order")
    for key in ("data", "split"):
        saved = checkpoint.get(key + "_sha256")
        if saved is not None and saved != hashes[key]:
            raise ValueError(f"Checkpoint does not match supplied {key} archive")
    if temp.shape[1] < model.profile_len or p.shape[1] != len(model.blocks):
        raise ValueError("Temperature or allocation dimensions do not match the checkpoint")
    fit_idx = np.arange(len(temp)) if args.cluster_fit == "all" else parts["train"]
    eval_idx = fit_idx if args.cluster_fit == "all" else parts["test"]
    centers, labels, cluster_info = cluster_allocations(
        p, lat, fit_idx, eval_idx, args.k, args.seed, args.n_init)
    ids = (np.concatenate([parts["val"], parts["test"]])
           if args.perturb_subset == "val-test" else parts[args.perturb_subset])
    target_mean = float(checkpoint["target_mean"])
    target_std = float(checkpoint["target_std"])
    if not np.isfinite([target_mean, target_std]).all() or target_std <= 0:
        raise ValueError("Checkpoint target normalization statistics are invalid")
    x = standardize_channels(build_5_channels(temp[ids, :model.profile_len]),
                             checkpoint["channel_mean"], checkpoint["channel_std"])
    baseline, ablated = channel_interventions(model, x, device, target_mean, target_std, args.batch_size)
    effects = np.abs(ablated - baseline[:, None])
    mae = float(np.abs(baseline - mld[ids]).mean())
    mae_delta = np.abs(ablated - mld[ids, None]).mean(axis=0) - mae
    report = {
        "source_sha256": hashes,
        "allocation_hash_fields_checked": checked,
        "allocation_provenance": "Only hash fields present in the archive can be verified.",
        "channel_order": list(CHANNELS),
        "cluster_fit": args.cluster_fit,
        "cluster_evaluation": "all_descriptive" if args.cluster_fit == "all" else "test",
        "cluster_fit_n": len(fit_idx),
        "cluster_eval_n": len(eval_idx),
        "k": args.k,
        "kmeans_seed": args.seed,
        "kmeans_n_init": args.n_init,
        "labels": "Zero-based IDs sorted by mean absolute latitude of fitting profiles; latitude is not a K-means feature.",
        "cluster_sizes": cluster_info,
        "adjacent_layer_transitions": adjacent_transitions(labels, p[eval_idx], args.k),
        "perturbation_subset": args.perturb_subset,
        "perturbation": "One full standardized feature channel set to zero; absolute final prediction change.",
        "perturbation_limitation": "This intervention does not recompute derived channels, and is not a physically consistent temperature perturbation.",
        "rank_tie_rule": args.rank_ties,
        "rank_tie_rule_definition": ("Average ranks in both directions, rank <= 2 in the respective direction."
                                     if args.rank_ties == "average" else
                                     "Minimum descending ranks: <= 2 for the high channel and >= 4 for the low channel."),
        "perturbation_effect_tie_n": int(np.sum(np.any(np.diff(np.sort(effects, axis=1), axis=1) == 0, axis=1))),
        "perturbation_baseline_mae": mae,
        "perturbation_channel_delta_mae": dict(zip(CHANNELS, mae_delta.tolist())),
        "allocation_rank_agreement": perturbation_agreement(p[ids], effects, args.rank_ties),
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "analysis.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    np.savez_compressed(args.out / "analysis_arrays.npz", cluster_fit_sample=fit_idx,
                        cluster_eval_sample=eval_idx, cluster_labels=labels, cluster_centers=centers,
                        perturbation_sample=ids, baseline=baseline, ablated=ablated, sensitivity=effects,
                        channels=np.array(CHANNELS))
    print(f"Saved {len(eval_idx)} cluster assignments per layer and {len(ids)} intervention profiles to {args.out}")


if __name__ == "__main__":
    main()
