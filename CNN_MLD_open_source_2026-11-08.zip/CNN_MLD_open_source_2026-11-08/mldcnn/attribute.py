"""Trace signed input-channel contributions through evaluation-mode Conv–BN–GELU."""
import argparse
import hashlib
import math
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from .model import CHANNEL_NAMES, build_5_channels, load_checkpoint, standardize_channels


def propagate_block(actual, reference, sources, block):
    """One block with the original BN scaling, residual handling and secant rule."""
    if block.training:
        raise ValueError("The convolutional block must be in evaluation mode")
    if not isinstance(block.act, torch.nn.GELU) or block.act.approximate != "none":
        raise ValueError("This implementation expects exact GELU")
    if block.conv.stride != (1,) or block.conv.groups != 1 or block.conv.padding_mode != "zeros":
        raise ValueError("Expected stride-one, ungrouped Conv1d with zero padding")

    z = block.bn(block.conv(actual))
    z_ref = block.bn(block.conv(reference))
    batch, n_sources, in_channels, length = sources.shape
    conv = block.conv
    source_pre = F.conv1d(sources.reshape(batch * n_sources, in_channels, length),
                          conv.weight, bias=None, padding=conv.padding, dilation=conv.dilation)
    source_pre = source_pre.reshape(batch, n_sources, z.shape[1], z.shape[2])
    scale = block.bn.weight / torch.sqrt(block.bn.running_var + block.bn.eps)
    source_pre = source_pre * scale.view(1, 1, -1, 1)

    delta = z - z_ref
    residual = delta - source_pre.sum(dim=1)
    magnitude = source_pre.abs()
    share = magnitude / magnitude.sum(dim=1, keepdim=True).clamp_min(1e-8)
    source_pre = source_pre + residual.unsqueeze(1) * share

    observed, baseline = block.act(z), block.act(z_ref)
    small = delta.abs() < 1e-6
    secant = (observed - baseline) / torch.where(small, torch.ones_like(delta), delta)
    derivative = (0.5 * (1.0 + torch.erf(z_ref / math.sqrt(2.0)))
                  + z_ref * torch.exp(-0.5 * z_ref.square()) / math.sqrt(2.0 * math.pi))
    multiplier = torch.where(small, derivative, secant)
    return observed, baseline, source_pre * multiplier.unsqueeze(1)


@torch.inference_mode()
def trace_batch(model, inputs, reference=None):
    """Return layerwise allocations and reconstruction errors for one batch.

    inputs and reference are already standardized. A zero reference is used by
    default. The signed source sum reconstructs the activation difference; the
    fractions summarize absolute magnitudes, not signed output effects.
    """
    if model.training or inputs.ndim != 3 or inputs.shape[1] != 5:
        raise ValueError("Expected an evaluation-mode model and inputs of shape (N, 5, L)")
    ref = torch.zeros_like(inputs) if reference is None else reference.expand_as(inputs)
    diagonal = torch.eye(5, dtype=inputs.dtype, device=inputs.device).view(1, 5, 5, 1)
    sources = (inputs - ref).unsqueeze(1) * diagonal
    actual = inputs
    fractions, errors = [], []
    for i, block in enumerate(model.blocks, start=1):
        actual, ref, sources = propagate_block(actual, ref, sources, block)
        errors.append(float((sources.sum(1) - (actual - ref)).abs().max().item()))
        energy = sources.abs().sum(dim=(2, 3))
        denom = energy.sum(1, keepdim=True)
        if not torch.isfinite(energy).all() or (denom <= 0).any():
            raise ValueError(f"Conv{i}: at least one profile has nonfinite or zero total attribution magnitude")
        fractions.append(energy / denom)
    return torch.stack(fractions, dim=1), np.asarray(errors)


def sha256(path):
    with Path(path).open("rb") as stream:
        digest = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path, help="Output allocation .npz file")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--threads", type=int, default=2, help="Number of CPU intra-op threads")
    args = parser.parse_args()
    if args.batch_size < 1 or args.threads < 1 or args.out.suffix.lower() != ".npz":
        parser.error("Use positive --batch-size/--threads and an .npz output")
    if args.out.resolve() in (args.data.resolve(), args.checkpoint.resolve()):
        parser.error("--out must not overwrite an input file")
    torch.set_num_threads(args.threads)
    model, checkpoint = load_checkpoint(args.checkpoint, args.device)
    model.eval()
    length = checkpoint["model_config"]["profile_len"]
    with np.load(args.data, allow_pickle=False) as data:
        temperature = data["temperature"]
    if temperature.ndim != 2 or len(temperature) == 0 or temperature.shape[1] < length:
        raise ValueError("temperature must be nonempty and contain at least the model's profile length")
    results = []
    max_error = np.zeros(len(model.blocks))
    for start in range(0, len(temperature), args.batch_size):
        features = build_5_channels(temperature[start:start + args.batch_size, :length])
        normalized = standardize_channels(features, checkpoint["channel_mean"], checkpoint["channel_std"])
        batch = torch.as_tensor(normalized, dtype=torch.float32, device=args.device)
        p, error = trace_batch(model, batch)
        max_error = np.maximum(max_error, error)
        results.append(p.cpu().numpy())
    p = np.concatenate(results)
    if not np.isfinite(p).all() or not np.allclose(p.sum(2), 1, atol=1e-5):
        raise RuntimeError("Invalid allocation fractions")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out, P=p, sample=np.arange(len(p)), channels=np.asarray(CHANNEL_NAMES),
                        reference=np.array("standardized_zero"), reconstruction_max_abs=max_error,
                        data_sha256=np.array(sha256(args.data)), checkpoint_sha256=np.array(sha256(args.checkpoint)))
    print(f"Allocation shape: {p.shape}; max reconstruction error by layer: {max_error.tolist()}")


if __name__ == "__main__":
    main()
