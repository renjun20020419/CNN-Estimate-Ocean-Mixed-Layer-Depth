"""Generate an entirely synthetic dataset for checking the command-line workflow."""
import argparse
from pathlib import Path

import numpy as np


def synthetic_profiles(n=240, length=64, seed=42):
    """Toy profiles and labels; not ocean observations or physical validation."""
    if n < 50 or length < 16:
        raise ValueError("Use at least 50 profiles and 16 depth levels for the demo")
    rng = np.random.default_rng(seed)
    lat = rng.uniform(-75, 75, n)
    lon = rng.uniform(-180, 180, n)
    target = (0.15 + 0.40 * rng.random(n)) * (length - 1)
    levels = np.arange(length)[None, :]
    surface = 25.0 - 0.25 * np.abs(lat) + rng.normal(0, 1.0, n)
    cooling = rng.uniform(4.0, 12.0, n)
    thermal_transition = 1.0 / (1.0 + np.exp(-(levels - target[:, None]) / 3.0))
    temperature = surface[:, None] - cooling[:, None] * thermal_transition
    temperature += rng.normal(0, 0.04, (n, length))
    return dict(temperature=temperature.astype(np.float32), mld=target.astype(np.float32),
                lat=lat, lon=lon, profile_id=np.array([f"synthetic_{i:05d}" for i in range(n)]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--samples", type=int, default=240)
    parser.add_argument("--levels", type=int, default=64)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.out.suffix.lower() != ".npz":
        parser.error("--out must end in .npz")
    if args.out.exists():
        parser.error("Output exists; choose a new file for synthetic data")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out, **synthetic_profiles(args.samples, args.levels, args.seed))
    print(f"Saved {args.samples} synthetic profiles with {args.levels} levels")


if __name__ == "__main__":
    main()
