"""Five-channel preprocessing and the displayed Conv-BN-GELU MLD model."""

from pathlib import Path

import numpy as np
import torch
from torch import nn


CHANNEL_NAMES = (
    "temperature",
    "temperature_gradient",
    "temperature_second_gradient",
    "cumulative_variance",
    "cumulative_variance_gradient",
)


def build_5_channels(temperature: np.ndarray) -> np.ndarray:
    """Map finite (N, L) temperature profiles to float32 (N, 5, L) inputs.

    Gradients use unit sample spacing and NumPy's one-sided edge rule,
    as in the study implementation. Cumulative variance uses ddof=0 and
    includes the current level. This function does not interpolate depth.
    """
    temp = np.asarray(temperature, dtype=np.float32)
    if temp.ndim != 2 or temp.shape[0] == 0 or temp.shape[1] < 2:
        raise ValueError("temperature must have shape (N, L), with N > 0 and L >= 2")
    if not np.isfinite(temp).all():
        raise ValueError("temperature must contain only finite values")
    grad = np.gradient(temp, axis=1).astype(np.float32)
    grad2 = np.gradient(grad, axis=1).astype(np.float32)
    cumulative_var = np.empty_like(temp, dtype=np.float32)
    for i in range(temp.shape[1]):
        cumulative_var[:, i] = np.var(temp[:, : i + 1], axis=1)
    variance_grad = np.gradient(cumulative_var, axis=1).astype(np.float32)
    features = np.stack([temp, grad, grad2, cumulative_var, variance_grad], axis=1)
    if not np.isfinite(features).all():
        raise ValueError("five-channel preprocessing produced nonfinite values")
    return features


def standardize_channels(features, channel_mean, channel_std) -> np.ndarray:
    """Apply training-fitted per-channel statistics to (N, 5, L) features."""
    x = np.asarray(features, dtype=np.float32)
    if x.ndim != 3 or x.shape[1] != len(CHANNEL_NAMES):
        raise ValueError("features must have shape (N, 5, L)")
    mean = np.asarray(channel_mean, dtype=np.float32).reshape(1, 5, 1)
    std = np.asarray(channel_std, dtype=np.float32).reshape(1, 5, 1)
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std <= 0):
        raise ValueError("channel means must be finite and standard deviations finite and positive")
    result = (x - mean) / std
    if not np.isfinite(result).all():
        raise ValueError("standardization produced nonfinite values")
    return result


class ConvBlock(nn.Module):
    """One same-length Conv1d, BatchNorm1d, and exact GELU block."""

    def __init__(self, in_channels: int, out_channels: int, kernel_size: int):
        super().__init__()
        if kernel_size < 1 or kernel_size % 2 != 1:
            raise ValueError("kernel sizes must be positive odd integers")
        self.conv = nn.Conv1d(
            in_channels, out_channels, kernel_size, padding=(kernel_size - 1) // 2
        )
        self.bn = nn.BatchNorm1d(out_channels)
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.bn(self.conv(x)))


class ProfileCNN(nn.Module):
    """CNN returning one standardized MLD prediction per temperature profile.

    Defaults reproduce the displayed model: four 250-map blocks, kernel 15,
    then a 1x1 convolution and a linear readout over the profile levels.
    """

    def __init__(
        self,
        profile_len: int = 500,
        channels: tuple[int, ...] = (250, 250, 250, 250),
        kernel_sizes: tuple[int, ...] = (15, 15, 15, 15),
    ):
        super().__init__()
        if not isinstance(profile_len, int) or profile_len < 2:
            raise ValueError("profile_len must be an integer >= 2")
        if not channels or len(channels) != len(kernel_sizes):
            raise ValueError("channels and kernel_sizes must be nonempty and equally long")
        if any(not isinstance(c, int) or c < 1 for c in channels):
            raise ValueError("channels must be positive integers")
        if any(not isinstance(k, int) or k < 1 or k % 2 != 1 for k in kernel_sizes):
            raise ValueError("kernel_sizes must be positive odd integers")
        self.profile_len = profile_len
        self.channels = tuple(channels)
        self.kernel_sizes = tuple(kernel_sizes)
        self.head_type = "directdepth"
        self._block_names = tuple(f"conv{i}" for i in range(1, len(channels) + 1))
        for name, ci, co, k in zip(self._block_names, (5, *self.channels[:-1]), channels, kernel_sizes):
            setattr(self, name, ConvBlock(ci, co, k))
        self.score_head = nn.Conv1d(channels[-1], 1, kernel_size=1)
        self.depth_head = nn.Linear(profile_len, 1)

    @property
    def blocks(self) -> tuple[ConvBlock, ...]:
        return tuple(getattr(self, name) for name in self._block_names)

    @property
    def model_config(self) -> dict:
        return {
            "profile_len": self.profile_len,
            "channels": list(self.channels),
            "kernel_sizes": list(self.kernel_sizes),
        }

    def forward(self, x: torch.Tensor, return_activations: bool = False, return_logits: bool = False):
        if x.ndim != 3 or x.shape[1:] != (5, self.profile_len):
            raise ValueError(f"model input must have shape (N, 5, {self.profile_len})")
        activations = {}
        for name, block, width in zip(self._block_names, self.blocks, self.channels):
            x = block(x)
            if return_activations:
                activations[f"{name}_{width}"] = x
        logits = self.score_head(x).squeeze(1)
        output = self.depth_head(logits).squeeze(-1)
        if return_activations and return_logits:
            return output, activations, logits
        if return_activations:
            return output, activations
        if return_logits:
            return output, logits
        return output


def load_checkpoint(path: str | Path, device: str | torch.device = "cpu") -> tuple[ProfileCNN, dict]:
    """Load a checkpoint written by mldcnn.train without enabling pickle code execution."""
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    model = ProfileCNN(**checkpoint["model_config"])
    model.load_state_dict(checkpoint["state_dict"])
    return model.to(device).eval(), checkpoint
