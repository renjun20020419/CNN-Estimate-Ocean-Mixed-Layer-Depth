"""Coordinate-only, group-preserving train/validation/test partition."""
import argparse
from pathlib import Path

import numpy as np


def spatial_split(lat, lon, seed=20261016):
    """Assign entire 10-degree cells; balance counts and six latitude bands."""
    lat = np.asarray(lat, dtype=np.float64)
    lon = np.asarray(lon, dtype=np.float64)
    if lat.ndim != 1 or lat.shape != lon.shape:
        raise ValueError("lat and lon must be equally sized one-dimensional arrays")
    if not (np.isfinite(lat).all() and np.isfinite(lon).all() and (np.abs(lat) <= 90).all()):
        raise ValueError("Use finite coordinates in degrees and latitude in [-90, 90]")
    lat_bin = np.minimum(np.floor((lat + 90.0) / 10.0).astype(int), 17)
    wrapped_lon = (lon + 180.0) % 360.0 - 180.0
    lon_bin = np.floor((wrapped_lon + 180.0) / 10.0).astype(int)
    grid_id = np.array([f"{a}_{b}" for a, b in zip(lat_bin, lon_bin)], dtype=str)
    # Lexicographic group order preserves the archived split's tie handling.
    groups, inverse, sizes = np.unique(grid_id, return_inverse=True, return_counts=True)
    if len(groups) < 3:
        raise ValueError("At least three occupied spatial cells are needed")
    group_band = np.array([int(g.split("_")[0]) // 3 for g in groups])
    fractions = np.array([0.8, 0.1, 0.1])
    target = len(lat) * fractions
    band_target = np.bincount(group_band, weights=sizes, minlength=6)[:, None] * fractions
    counts = np.zeros(3)
    band_counts = np.zeros((6, 3))
    assignment = np.full(len(groups), -1)
    rng = np.random.default_rng(seed)

    def objective(c, b):
        return np.sum((c - target) ** 2 / target) + 0.20 * np.sum(
            (b - band_target) ** 2 / np.maximum(band_target, 1)
        )

    for g in np.lexsort((rng.random(len(groups)), -sizes)):
        size, band = float(sizes[g]), group_band[g]
        costs = []
        for subset in range(3):
            c, b = counts.copy(), band_counts.copy()
            c[subset] += size
            b[band, subset] += size
            costs.append(objective(c, b))
        subset = int(np.argmin(costs))
        assignment[g] = subset
        counts[subset] += size
        band_counts[band, subset] += size

    for _ in range(40):
        improved = False
        for g in rng.permutation(len(groups)):
            old = assignment[g]
            size, band = float(sizes[g]), group_band[g]
            best, chosen = objective(counts, band_counts), old
            for subset in range(3):
                if subset == old:
                    continue
                c, b = counts.copy(), band_counts.copy()
                c[old] -= size
                b[band, old] -= size
                c[subset] += size
                b[band, subset] += size
                cost = objective(c, b)
                if cost < best - 1e-10:
                    best, chosen = cost, subset
            if chosen != old:
                assignment[g] = chosen
                counts[old] -= size
                band_counts[band, old] -= size
                counts[chosen] += size
                band_counts[band, chosen] += size
                improved = True
        if not improved:
            break

    result = {f"{name}_idx": np.flatnonzero(assignment[inverse] == i)
              for i, name in enumerate(("train", "val", "test"))}
    if any(not len(ids) for ids in result.values()):
        raise ValueError("This grid/count objective produced an empty subset; supply a suitable split")
    result.update(grid_id=grid_id, split_seed=np.array(seed))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path, help="Output split .npz file")
    parser.add_argument("--seed", type=int, default=20261016)
    args = parser.parse_args()
    if args.out.suffix.lower() != ".npz":
        parser.error("--out must end in .npz")
    if args.data.resolve() == args.out.resolve():
        parser.error("--out must not overwrite the input dataset")
    with np.load(args.data, allow_pickle=False) as data:
        result = spatial_split(data["lat"], data["lon"], args.seed)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.out, **result)
    for name in ("train", "val", "test"):
        ids = result[f"{name}_idx"]
        print(f"{name}: {len(ids)} profiles, {len(np.unique(result['grid_id'][ids]))} cells")


if __name__ == "__main__":
    main()
