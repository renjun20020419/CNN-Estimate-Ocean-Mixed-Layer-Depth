"""Train the mixed-layer-depth CNN from user-supplied NPZ data and split."""

import argparse
import csv
import hashlib
import json
import math
import random
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from .model import CHANNEL_NAMES, ProfileCNN, build_5_channels, standardize_channels


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_split(path: Path, n: int) -> dict[str, np.ndarray]:
    """Require a disjoint, exhaustive partition of the original input rows."""
    with np.load(path, allow_pickle=False) as z:
        subsets = {}
        for name in ("train", "val", "test"):
            x = z[f"{name}_idx"]
            if x.ndim != 1 or x.size == 0 or not np.issubdtype(x.dtype, np.integer):
                raise ValueError(f"{name}_idx must be a nonempty 1-D integer array")
            if np.any(x < 0) or np.any(x >= n):
                raise ValueError(f"{name}_idx contains an out-of-range row index")
            subsets[name] = x.astype(np.int64, copy=False)
    combined = np.concatenate(list(subsets.values()))
    if not np.array_equal(np.sort(combined), np.arange(n)):
        raise ValueError("train, validation, and test must partition all data rows without duplicates")
    return subsets


def make_loader(x, y, batch_size, shuffle, device):
    ds = TensorDataset(torch.from_numpy(x), torch.from_numpy(y))
    return DataLoader(
        ds, batch_size=batch_size, shuffle=shuffle, num_workers=0,
        pin_memory=(device.type == "cuda"),
    )


@torch.no_grad()
def evaluate(model, loader, device, target_mean, target_std):
    model.eval()
    predictions = []
    targets = []
    squared_scaled_error = 0.0
    for xb, yb in loader:
        xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
        prediction = model(xb)
        squared_scaled_error += nn.functional.mse_loss(prediction, yb, reduction="sum").item()
        predictions.append(prediction.cpu().numpy())
        targets.append(yb.cpu().numpy())
    pred = np.concatenate(predictions) * target_std + target_mean
    true = np.concatenate(targets) * target_std + target_mean
    if not np.isfinite(pred).all() or not np.isfinite(true).all():
        raise FloatingPointError("nonfinite prediction or target during evaluation")
    error = pred - true
    ss_res = float(np.sum(error * error))
    ss_tot = float(np.sum((true - np.mean(true)) ** 2))
    return {
        "mae": float(np.mean(np.abs(error))),
        "rmse": math.sqrt(float(np.mean(error * error))),
        "bias": float(np.mean(error)),
        "r2": 1.0 - ss_res / ss_tot if ss_tot > 0 else None,
        "loss_mse_scaled": squared_scaled_error / len(true),
    }, pred


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True, help="NPZ: temperature (N,L), mld (N,)")
    parser.add_argument("--split", type=Path, required=True, help="NPZ: train_idx, val_idx, test_idx")
    parser.add_argument("--out", type=Path, required=True, help="output directory for this run")
    parser.add_argument("--profile-len", type=int, help="optionally use only the first L levels")
    parser.add_argument("--seed", type=int, default=20260617)
    parser.add_argument("--epochs", "--max-epochs", type=int, default=300)
    parser.add_argument("--patience", type=int, default=45)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--learning-rate", "--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--channels", type=int, nargs="+", default=[250, 250, 250, 250])
    parser.add_argument("--kernel-sizes", type=int, nargs="+", help="one positive odd width per block (default 15)")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or e.g. cuda:1")
    parser.add_argument("--num-threads", type=int, default=4, help="PyTorch CPU thread limit")
    args = parser.parse_args(argv)
    if args.kernel_sizes is None:
        args.kernel_sizes = [15] * len(args.channels)
    if min(args.epochs, args.patience, args.batch_size, args.num_threads) < 1:
        parser.error("epochs, patience, batch-size, and num-threads must be positive")
    if not 0 <= args.seed < 2**32:
        parser.error("seed must be in [0, 2^32)")
    if not math.isfinite(args.learning_rate) or args.learning_rate <= 0:
        parser.error("learning-rate must be finite and positive")
    if not math.isfinite(args.weight_decay) or args.weight_decay < 0:
        parser.error("weight-decay must be finite and nonnegative")
    return args


def main(argv=None):
    args = parse_args(argv)
    run_files = ("checkpoint.pt", "training_history.csv", "metrics.json", "predictions.npz")
    if any((args.out / name).exists() for name in run_files):
        raise FileExistsError("training output files already exist; choose a new --out directory")
    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    ) if args.device == "auto" else torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; use --device cpu")
    torch.set_num_threads(args.num_threads)
    set_seed(args.seed)

    with np.load(args.data, allow_pickle=False) as z:
        temp = np.asarray(z["temperature"], dtype=np.float32)
        target = np.asarray(z["mld"], dtype=np.float32)
    if temp.ndim != 2 or target.shape != (len(temp),):
        raise ValueError("expected temperature (N,L) and mld (N,)")
    if not np.isfinite(target).all():
        raise ValueError("mld must contain only finite values")
    if args.profile_len is not None:
        if not 2 <= args.profile_len <= temp.shape[1]:
            raise ValueError("profile-len must be between 2 and the available number of levels")
        temp = temp[:, :args.profile_len]
    subsets = read_split(args.split, len(target))
    x = build_5_channels(temp)
    train = subsets["train"]
    channel_mean = x[train].mean(axis=(0, 2), keepdims=True).astype(np.float32)
    channel_std = x[train].std(axis=(0, 2), keepdims=True).astype(np.float32)
    channel_std[channel_std < 1e-6] = 1.0
    target_mean = float(target[train].mean())
    target_std = float(target[train].std())
    if not math.isfinite(target_mean) or not math.isfinite(target_std):
        raise ValueError("target normalization statistics must be finite")
    if target_std < 1e-6:
        target_std = 1.0
    x = standardize_channels(x, channel_mean, channel_std)
    y = ((target - target_mean) / target_std).astype(np.float32)
    if not np.isfinite(y).all():
        raise ValueError("target standardization produced nonfinite values")
    train_loader = make_loader(x[train], y[train], args.batch_size, True, device)
    val = subsets["val"]
    val_loader = make_loader(x[val], y[val], args.batch_size, False, device)
    model = ProfileCNN(temp.shape[1], args.channels, args.kernel_sizes).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=12, min_lr=1e-5
    )
    loss_fn = nn.SmoothL1Loss(beta=0.5)

    args.out.mkdir(parents=True, exist_ok=True)
    data_sha, split_sha = sha256(args.data), sha256(args.split)
    best_path = args.out / "checkpoint.pt"
    best_mae, best_epoch = float("inf"), 0
    print(f"Training on {device}: N={len(target)}, L={temp.shape[1]}, split sizes "
          f"{[len(v) for v in subsets.values()]}", flush=True)
    fields = ["epoch", "train_smooth_l1_scaled", "val_loss_mse_scaled", "val_mae", "val_rmse", "val_r2", "lr"]
    with (args.out / "training_history.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for epoch in range(1, args.epochs + 1):
            model.train()
            total = 0.0
            for xb, yb in train_loader:
                xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                loss = loss_fn(model(xb), yb)
                if not torch.isfinite(loss).item():
                    raise FloatingPointError("nonfinite training loss")
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
                optimizer.step()
                total += loss.item() * yb.numel()
            validation, _ = evaluate(model, val_loader, device, target_mean, target_std)
            scheduler.step(validation["loss_mse_scaled"])
            writer.writerow({
                "epoch": epoch, "train_smooth_l1_scaled": total / len(train),
                "val_loss_mse_scaled": validation["loss_mse_scaled"],
                "val_mae": validation["mae"], "val_rmse": validation["rmse"],
                "val_r2": validation["r2"], "lr": optimizer.param_groups[0]["lr"],
            })
            stream.flush()
            print(f"Epoch {epoch:03d}: validation MAE={validation['mae']:.6g}", flush=True)
            if validation["mae"] < best_mae - 1e-5:
                best_mae, best_epoch = validation["mae"], epoch
                torch.save({
                    "state_dict": {name: value.detach().cpu() for name, value in model.state_dict().items()},
                    "model_config": model.model_config,
                    "channel_mean": channel_mean.ravel().tolist(),
                    "channel_std": channel_std.ravel().tolist(),
                    "target_mean": target_mean, "target_std": target_std,
                    "channel_names": list(CHANNEL_NAMES), "seed": args.seed,
                    "epoch": epoch, "val_metrics": validation,
                    "data_sha256": data_sha, "split_sha256": split_sha,
                }, best_path)
            elif epoch - best_epoch >= args.patience:
                print(f"Early stopping at epoch {epoch}; best epoch {best_epoch}.", flush=True)
                break

    checkpoint = torch.load(best_path, map_location="cpu", weights_only=True)
    model.load_state_dict(checkpoint["state_dict"])
    predictions = np.empty_like(target)
    labels = np.empty(len(target), dtype="<U5")
    results = {}
    for name, idx in subsets.items():
        loader = make_loader(x[idx], y[idx], args.batch_size, False, device)
        results[name], predictions[idx] = evaluate(model, loader, device, target_mean, target_std)
        labels[idx] = name
    np.savez_compressed(
        args.out / "predictions.npz", mld_true=target, mld_pred=predictions, split=labels,
        **{f"{name}_idx": idx for name, idx in subsets.items()},
    )
    report = {
        "seed": args.seed, "best_epoch": best_epoch, "model_config": model.model_config,
        "data_sha256": data_sha, "split_sha256": split_sha, "device": str(device),
        "training": {
            "batch_size": args.batch_size, "max_epochs": args.epochs, "patience": args.patience,
            "learning_rate": args.learning_rate, "weight_decay": args.weight_decay,
            "optimizer": "AdamW", "loss": "SmoothL1(beta=0.5) on standardized targets",
            "checkpoint_selection": "validation MAE in the supplied target scale",
            "scheduler": "ReduceLROnPlateau on validation standardized MSE",
        },
        "n": {name: len(idx) for name, idx in subsets.items()}, "metrics": results,
    }
    (args.out / "metrics.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Saved best checkpoint (epoch {best_epoch}) and evaluation to {args.out}", flush=True)


if __name__ == "__main__":
    main()
