"""Small, observation-free checks of the public core implementation."""
import unittest

import numpy as np
import torch

from mldcnn.attribute import propagate_block, trace_batch
from mldcnn.demo import synthetic_profiles
from mldcnn.model import ProfileCNN, build_5_channels
from mldcnn.split import spatial_split


class CoreTests(unittest.TestCase):
    def test_features(self):
        temperature = np.array([[5.0, 4.0, 3.0, 2.0]], dtype=np.float32)
        features = build_5_channels(temperature)
        self.assertEqual(features.shape, (1, 5, 4))
        np.testing.assert_array_equal(features[:, 0], temperature)
        np.testing.assert_allclose(features[0, 1], -1)
        np.testing.assert_allclose(features[0, 2], 0)
        np.testing.assert_allclose(features[0, 3], [0, 1/4, 2/3, 5/4])

    def test_split(self):
        data = synthetic_profiles()
        first = spatial_split(data["lat"], data["lon"])
        second = spatial_split(data["lat"], data["lon"])
        indices = [first[k] for k in ("train_idx", "val_idx", "test_idx")]
        np.testing.assert_array_equal(np.sort(np.concatenate(indices)), np.arange(len(data["mld"])))
        sets = [set(first["grid_id"][ids]) for ids in indices]
        self.assertFalse((sets[0] & sets[1]) | (sets[0] & sets[2]) | (sets[1] & sets[2]))
        for key in first:
            np.testing.assert_array_equal(first[key], second[key])

    def test_conservation(self):
        torch.manual_seed(42)
        model = ProfileCNN(profile_len=32, channels=(8, 8, 8, 8), kernel_sizes=(3, 3, 3, 3)).eval()
        x, ref = torch.randn(4, 5, 32), torch.randn(1, 5, 32)
        with torch.inference_mode():
            y, _, sources = propagate_block(x, ref, (x - ref).unsqueeze(1) * torch.eye(5).reshape(1, 5, 5, 1), model.blocks[0])
            torch.testing.assert_close(y, model.blocks[0](x))
            self.assertEqual(sources.shape, (4, 5, 8, 32))
        p, error = trace_batch(model, x, ref)
        self.assertEqual(tuple(p.shape), (4, 4, 5))
        torch.testing.assert_close(p.sum(2), torch.ones(4, 4))
        self.assertTrue(np.all(error < 1e-5), error)


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
